<?php namespace App\Controllers;

class Pages extends BaseController
{
	public function index()
	{
		$data =[
			'title' => 'Home | Mila Karmila'
		];
		return view('Pages/home' ,$data);
	}
	public function about(){
		$data =[
			'title' => 'About Me'
		];
		return view('Pages/about' ,$data);
	}

	public function contact(){
		$data =[
			'title' => 'Contact Me',
			'alamat' =>[
				[
				'tipe'=> 'Rumah',
				'alamat' => 'Jl.ABC No.123',
				'kota'=>'Bandung'

			],
			[
				'tipe'=> 'Kantor',
				'alamat' => 'Jl.SetBud No.123',
				'kota'=>'Bandung'

			]
			];

		];
		return view('Pages/contact' ,$data);
	}


	//--------------------------------------------------------------------

}
