<?= $this->extend('Layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
	<div class="row">
    	<div class="col">
    		<h1>About Me</h1>
			<h1>Hello, world!</h1>    
    	</div>
    </div>
</div>
    
<?= $this->endSection(''); ?>
    